from flask import Flask, request, jsonify
import mysql.connector
import joblib
import smtplib

app = Flask(__name__)

# Load AI Model
model = joblib.load("donor_match_model.pkl")

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="kashish",
    database="food_donation"
)
cursor = conn.cursor()

# SMTP Email Configuration
EMAIL_USER = "your_email@gmail.com"
EMAIL_PASS = "your_password"

def send_email(to_email, subject, message):
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(EMAIL_USER, EMAIL_PASS)
    server.sendmail(EMAIL_USER, to_email, f"Subject: {subject}\n\n{message}")
    server.quit()

@app.route("/match-donor", methods=["POST"])
def match_donor():
    data = request.json
    food_needed, quantity = data["food_needed"], data["quantity"]

    cursor.execute("SELECT id, food, quantity FROM suppliers WHERE status='Available'")
    donors = cursor.fetchall()
    
    if not donors:
        return jsonify({"message": "❌ No donors available!"})

    # AI Model Prediction
    donor_id = model.kneighbors([[food_needed, quantity]], return_distance=False)[0][0]
    
    cursor.execute("SELECT email FROM suppliers WHERE id=%s", (donor_id,))
    donor_email = cursor.fetchone()[0]

    # Update requester status
    cursor.execute("UPDATE requesters SET status='Matched' WHERE email=%s", (data["email"],))
    conn.commit()

    # Notify donor
    send_email(donor_email, "Food Donation Request", f"A requester needs {food_needed}. Please contact them.")

    return jsonify({"message": "✅ Donor matched and notified!"})

@app.route("/check-expiry", methods=["GET"])
def check_expiry():
    cursor.execute("SELECT email, food, expiry_date FROM suppliers WHERE expiry_date <= CURDATE() + INTERVAL 2 DAY")
    expiring_food = cursor.fetchall()

    for email, food, expiry_date in expiring_food:
        send_email(email, "Food Expiry Alert", f"Your food '{food}' is expiring on {expiry_date}. Please donate it soon.")

    return jsonify({"message": "✅ Expiry alerts sent!"})

if __name__ == "__main__":
    app.run(debug=True)
