const tf = require("@tensorflow/tfjs-node");
const fs = require("fs");
const csv = require("csv-parser");

const data = [];
const labels = [];

fs.createReadStream("food_expiry_data.csv")
  .pipe(csv())
  .on("data", (row) => {
    const manufactureDate = new Date(row.manufacture_date).getTime();
    const shelfLife = parseInt(row.shelf_life);

    data.push([manufactureDate]);
    labels.push([shelfLife]);
  })
  .on("end", async () => {
    console.log("✅ Data loaded. Training the model...");

    const inputTensor = tf.tensor2d(data);
    const outputTensor = tf.tensor2d(labels);

    const model = tf.sequential();
    model.add(tf.layers.dense({ units: 10, inputShape: [1], activation: "relu" }));
    model.add(tf.layers.dense({ units: 1 }));

    model.compile({ optimizer: "adam", loss: "meanSquaredError" });

    await model.fit(inputTensor, outputTensor, { epochs: 100 });
    
    await model.save("file://./model");
    console.log("✅ Model trained and saved successfully!");
  });
