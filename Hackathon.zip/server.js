require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const fs = require("fs");
const fastCsv = require("fast-csv");

const app = express();
app.use(express.json());
const port = 3000;
app.use(cors());

// MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "kashish",
    database: "food_donation"
});

db.connect(err => {
    if (err) {
        console.error("❌ Database connection failed:", err.message);
    } else {
        console.log("✅ Connected to MySQL Database!");
    }
});

// Route for form submission
app.post('/submit-message', (req, res) => {
    const { name, email, message } = req.body;

    // Log the data to see what is being received
    console.log('Received data:', { name, email, message });

    if (!name || !email || !message) {
        return res.status(400).json({ message: '❌ All fields are required!' });
    }

    const sql = 'INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)';
    db.query(sql, [name, email, message], (err, result) => {
        if (err) {
            console.error('❌ Error inserting data:', err);
            return res.status(500).json({ message: '❌ Failed to store data.' });
        }
        res.json({ message: '✅ Your message has been sent successfully!' });
    });
});


// Fetch available donations with phone number
app.get("/donations", (req, res) => {
    const sql = "SELECT id, organization, food, quantity, manufacturing_date, shelf_life, email, phone, status FROM suppliers WHERE status = 'available'";

    db.query(sql, (err, results) => {
        if (err) {
            console.error("❌ Database error:", err);
            return res.status(500).json({ message: "❌ Database error", error: err });
        }
        res.json(results);
    });
});

// Update donation status (Claim)
app.put("/claim-donation/:id", (req, res) => {
    const { id } = req.params;

    if (!id) {
        return res.status(400).json({ success: false, message: "❌ Invalid donation ID" });
    }

    const updateSql = "UPDATE suppliers SET status = 'claimed' WHERE id = ? AND status = 'available'";

    db.query(updateSql, [id], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ success: false, message: "❌ Database error", error: err });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: "❌ Donation not found or already claimed" });
        }

        // Successfully updated the donation status
        res.json({ success: true, message: "✅ Donation claimed successfully!" });
    });
});

// Add new food supplier
app.post("/addSupplier", (req, res) => {
    const { organization, food, quantity, manufacturing_date, email, shelf_life, phone } = req.body;

    if (!organization || !food || !quantity || !manufacturing_date || !email || !shelf_life || !phone) {
        return res.status(400).json({ message: "❌ All fields are required!" });
    }

    const sql = "INSERT INTO suppliers (organization, food, quantity, manufacturing_date, shelf_life, email, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'available')";

    db.query(sql, [organization, food, quantity, manufacturing_date, shelf_life, email, phone], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ message: "❌ Database error", error: err });
        }
        res.json({ message: `✅ Food supplier added successfully! Shelf life: ${shelf_life} days` });
    });
});

// Export donations to CSV
app.get("/export-csv", (req, res) => {
    const sql = "SELECT id, organization, food, quantity, manufacturing_date, shelf_life, email, phone, status FROM suppliers";

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ message: "❌ Database error", error: err });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: "❌ No data available" });
        }

        const filePath = "food_suppliers.csv";
        const ws = fs.createWriteStream(filePath);

        fastCsv
            .write(results, { headers: true })
            .pipe(ws)
            .on("finish", () => {
                res.download(filePath, "donation_history.csv", err => {
                    if (err) {
                        console.error("❌ CSV Download Error:", err);
                    }
                    setTimeout(() => fs.unlinkSync(filePath), 5000); // Delete file after download
                });
            });
    });
});

// Nodemailer setup
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL,
        pass: process.env.EMAIL_PASSWORD
    }
});

// Register volunteer and send email confirmation
app.post("/registerVolunteer", (req, res) => {
    const { name, email, phone, address, skills } = req.body;

    if (!name || !email || !phone || !address || !skills) {
        return res.status(400).json({ message: "❌ All fields are required!" });
    }

    const sql = "INSERT INTO volunteers (name, email, phone, address, skills) VALUES (?, ?, ?, ?, ?)";

    db.query(sql, [name, email, phone, address, skills], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ message: "❌ Database error", error: err });
        }

        // Prepare and send the confirmation email
        const mailOptions = {
            from: process.env.EMAIL,
            to: email,
            subject: 'Volunteer Registration Confirmation',
            text: `Hello ${name},\n\nThank you for registering as a volunteer with us. Your application has been successfully submitted.\n\nBest regards,\nThe Team`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error("❌ Error sending email:", error);
                return res.status(500).json({ message: "❌ Failed to send confirmation email." });
            }
            console.log("✅ Email sent: " + info.response);
            res.json({ message: `✅ Volunteer ${name} registered successfully!` });
        });
    });
});

app.listen(port, () => console.log(`🚀 Server running on http://localhost:${port}`));
